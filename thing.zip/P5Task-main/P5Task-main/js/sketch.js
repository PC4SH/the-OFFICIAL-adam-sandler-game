"use strict";
var r;
var g;
var b;

var mode = 0

var EnemySprite
var bg
var winSprite

let paddle;
let ball;
let bricks;
let leftbarrier;
let rightbarrier;
let topbarrier;
let shieldBarrier;

let MAX_SPEED = 12;
let MIN_SPEED = 8;
let score = 0;

let biggerPaddle;
let smollerPaddle;

let song;

let enemy;
let win;

let loss;
let lossImage;

let spawnPowerupTimer = 5;
let powerupTimer = 10;
let startPowerupTimer = false

let spawnSmollTimer = 5;
let smollTimer = 10;
let startSmollTimer = false

let spawnEnemyTimer = 15;
let startEnemyTimer = true;


function preload(){
    EnemySprite = loadImage("./images/adam.png")
    bg = loadImage("./images/rainbow.jpg")
    winSprite = loadImage("./images/will.png")
    lossImage = loadImage("./images/eviladamsandler.png")
    song = loadSound('./images/muzak.mp3');
}

function setup(){
    createCanvas(1920,940);
    paddle = new Sprite();
	paddle.width = 200;
	paddle.height = 15;
    paddle.color = 'grey';
    paddle.collider = 'kinematic';

    leftbarrier = new Sprite(0,470);
	leftbarrier.width = 5;
	leftbarrier.height = 940;
    leftbarrier.color = 'white';
    leftbarrier.collider = 'kinematic';
    
    rightbarrier = new Sprite(1920,470);
	rightbarrier.width = 5;
	rightbarrier.height = 940;
    rightbarrier.color = 'white';
    rightbarrier.collider = 'kinematic';

    topbarrier = new Sprite(960,0);
	topbarrier.width = 1920;
	topbarrier.height = 5;
    topbarrier.color = 'white';
    topbarrier.collider = 'kinematic';

    paddle.y = (900);

    ball = new Sprite();
	ball.diameter = 30;
    paddle.color = 'grey';

    ball.collider = 'dynamic'; //collide with & be moved by other sprites
    ball.rotationLock = true; //don't rotate
    ball.friction = 0;        //reduce friction, makes movement more bouncy
    ball.speed = 5;   //set initial speed
    ball.direction = 'down';  //set initial direction
    ball.bounciness = 1.10

    createBricks();
}

function draw(){
    if (mode == 0) {
        screen1();
    } else if (mode == 1) {
        screen2();
    }
}

function screen1() {

    background(bg);
    textSize(42);
    fill(random(0,255), random(0,255), random(0,255));
    text("CLIDKC MOUSE TO PLAY GAM#!!!", 960, height/2)

}

function screen2() {
    if (song.isPlaying()) {
    } else {
    song.play();
    }
    background(bg);

    textSize(42);
    fill(0,0,0);
    text("Score:", 20, 900)

    textSize(42);
    fill(random(0,255), random(0,255), random(0,255));
    text(score, 160, 900)

    if(mouseX > 100 && mouseX < 1820){
        paddle.x = (mouseX);
    }

    ball.color=color(random(0,255), random(0,255), random(0,255));

    if(ball.speed > MAX_SPEED){
        ball.speed = MAX_SPEED
    }

    if(ball.speed < MIN_SPEED){
        ball.speed = MIN_SPEED
    }

    paddle.collided(ball, paddleHitBall)

    ball.collided(bricks, ballHitBrick)

    if (bricks.length ==0){

        fill(random(0,255), random(0,255), random(0,255));
        textSize(100)
        text("YUO WIN!!!!11", 960, height/2)
        ball.remove()
        win = new Sprite();
        win.img = winSprite
        win.width = 350;
	    win.height = 600;
        win.x = 300;
        win.y = 600;
    }

    if (ball.y > 940){

        fill(random(0,255), random(0,255), random(0,255));
        textSize(100)
        text("YUO LOSERD!!!!!!11", 960, height/2)
        textSize(70)
        text("RE FRESH TO TRY AGIAN! !", 960, height/2+70)

        loss = new Sprite();
        loss.img = lossImage
        loss.width = 350;
	    loss.height = 600;
        loss.x = 300;
        loss.y = 600;

    }

    if(biggerPaddle){
        ball.collided(biggerPaddle, ballHitPowerup);
    }

    if(smollerPaddle){
        ball.collided(smollerPaddle, ballHitSmollPaddle);
    }

    if (frameCount % 60 == 0 && spawnPowerupTimer > 0) {
        spawnPowerupTimer --;
    }

    if (spawnPowerupTimer === 0) {
        spawnPowerupTimer = null
        spawnPowerup();
    }

    if(startPowerupTimer && frameCount % 60 == 0 && powerupTimer > 0){
        powerupTimer --;

    }

    if(powerupTimer == 0){
        startPowerupTimer = false;
        powerupTimer = 10;
        paddle.width = 200;
    }

    if (frameCount % 60 == 0 && spawnSmollTimer > 0) {
        spawnSmollTimer --;
    }

    if (spawnSmollTimer === 0) {
        spawnSmollTimer = null
        spawnSmallPowerup();
    }

    if(startSmollTimer && frameCount % 60 == 0 && smollTimer > 0){
        smollTimer --;
    }

    if(smollTimer == 0){
        startSmollTimer = false;
        smollTimer = 10;
        paddle.width = 200;
    }


    if (startEnemyTimer && frameCount % 60 == 0 && spawnEnemyTimer > 0) {
        spawnEnemyTimer --;
    }

    if (spawnEnemyTimer === 0) {
        spawnEnemyTimer = null;
        startEnemyTimer = false;
        spawnEnemy();
    }

    if(enemy){
        ball.collided(enemy, ballHitEnemy);
    }
  }

function paddleHitBall(paddle, ball){
    let swing = map(ball.position.x-paddle.position.x, 0, 50, 0, 25);
    //adjust the direction
    ball.direction = ball.direction + swing;
}

function ballHitBrick(ball, brick){
    if(brick.cool){
        shieldBarrier = new Sprite(960,840);
        shieldBarrier.width = 1920;
        shieldBarrier.height = 5;
        shieldBarrier.color = 'blue';
        shieldBarrier.collider = 'kinematic';
        shieldBarrier.velocity.y = 1;
    }
    brick.remove()
    score+= 100;
}

function spawnPowerup(){
    biggerPaddle = new Sprite();
	biggerPaddle.width = 150;
	biggerPaddle.height = 75;
    biggerPaddle.color = 'pink';
    biggerPaddle.x = random(100, 1700);
    biggerPaddle.y = 600;
    biggerPaddle.textSize = 20;
    biggerPaddle.text = "big padel :)"
}

function spawnSmallPowerup(){
    smollerPaddle = new Sprite();
	smollerPaddle.width = 150;
	smollerPaddle.height = 75;
    smollerPaddle.color = 'green';
    smollerPaddle.x = random(100, 1700);
    smollerPaddle.y = 600;
    smollerPaddle.textSize = 20;
    smollerPaddle.text = "smoll padel :("
}

function ballHitPowerup(){
    paddle.width = 400;
    biggerPaddle.remove()
    startPowerupTimer = true;
    spawnPowerupTimer = 15
}

function ballHitSmollPaddle(){
    paddle.width = 100;
    smollerPaddle.remove()
    startSmollTimer = true;
    spawnSmollTimer = 15
}

function mousePressed() {
    if (mode == 0) {
      mode = 1;
    }
}

function spawnEnemy(){
    enemy = new Sprite();
    enemy.img = EnemySprite
	enemy.width = 150;
	enemy.height = 75;
    enemy.x = random(100, 1700);
    enemy.y = 600;
    enemy.velocity.x = 1;
}

function ballHitEnemy(){
    enemy.remove()
    startEnemyTimer = true;
    spawnEnemyTimer = random(15,30)
    score+= 500;
}