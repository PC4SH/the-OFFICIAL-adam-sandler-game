function createBricks(){
    bricks = new Group();
	//bricks.y = 25;

    start = 150

    makeBrickRow(start);
    makeBrickRow(start+80);
    makeBrickRow(start+160);

}

function makeBrickRow(y){
    let x=30;
    while(x<width - 70) {
        r = random(255); // r is a random number between 0 - 255
        g = random(100,200); // g is a random number betwen 100 - 200
        b = random(100); // b is a random number between 0 - 100

        let brick = new bricks.Sprite();
        brick.collider="static";
        brick.w=random(80,150)
        brick.y = y
        let chance=random([false,false,false,true]);
        if(chance){
            brick.cool=true;
            brick.colour="red"
            brick.text = "Cool block"
        } else {
            brick.cool=false;
        }
        brick.x = x+brick.w/2;
        brick.height = 75;
        x+=brick.w+10;
    }
}